package com.tweet.app.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkacloudstreamproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
