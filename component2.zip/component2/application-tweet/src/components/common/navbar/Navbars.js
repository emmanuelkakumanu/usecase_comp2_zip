import React from 'react';



 class Navbars extends React.Component{
    render(){
        return(
    //     <section className="navbar">
    //     <Link to="/post" className="navbar-item">Post</Link>
    //     <Link to="/view" className="navbar-item">View</Link>
    //     <Link to="/viewAll" className="navbar-item">View All</Link>
    //     <Link to="/logout" className="navbar-item">LogOut</Link>
        
    // </section>
{/* <>
<div>
<Navbar fixed="top" bg="dark" variant="dark" > 
    <h id="header"> truYum   </h>
       <img   alt=" " src="/logo.png" width="30"  height="30"  /> 
          <Navbar.Brand id="menu-align" href="/menu" > Menu </Navbar.Brand>
</Navbar>
</div>
<div>
<Navbar fixed ="bottom" bg="light" variant="dark">
    Copyright @ 2019
</Navbar>
</div>
</> */}
        );
    }
}
export default Navbars;