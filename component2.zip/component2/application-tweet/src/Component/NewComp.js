import React from 'react'

export class NewComp extends React.Component{
    

}