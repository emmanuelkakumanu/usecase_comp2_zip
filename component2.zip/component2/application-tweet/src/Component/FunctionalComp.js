import React from 'react'

function FunctionalComp(){
    return <p>This is FunctionalComponent</p>
}

export default FunctionalComp;